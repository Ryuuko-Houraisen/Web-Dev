/*jshint esversion: 6 */
/*jshint esversion: 11 */
const cards = document.querySelectorAll('.card');
const addCard = document.querySelector('#addCard');

/* Add Card Logic */

const addCardToBank = (event) => { // Once called, creates a card to the board (bank)
  const card = createCard();
  const bank = document.querySelector('#bank');
  bank.appendChild(card);
}

addCard.onclick = addCardToBank;

/* Card Logic */
const createCard = (id, cardData) => {
  const card = document.createElement('div');
  card.classList.add('card');
  card.setAttribute('draggable', 'true');
  card.id = id || Date.now(); // If ID turns out to be a false value, will return Date.now
  card.ondragstart = onDragStart;
  card.ondragend = onDragEnd;
  card.onclick = deleteCard;
  if (cardData && cardData.imageSrc) {
    const image = new Image(100, 85);
    image.src = cardData.imageSrc;
    image.style.pointerEvents = 'none';
    card.appendChild(card);
  } else {
    appendImage(card);
  }
  return card;
}

const appendImage = (card) => {
  const input = document.createElement('input');
  input.setAttribute('type', 'file');  // Only accepts files instead of text
  input.setAttribute('accept', 'image/x-png,image/gif,image/jpeg'); // Only accept images
  input.style.visibility = 'hidden'; // Users cannot see that they can drag and drop images
  input.onchange = () => {
    const image = new Image(100, 85); // Card height and width
    const file = input.files[0];
    console.log(file);

    const reader = new FileReader(); // Allows files to be read so we can get the source content
    reader.onload = (event) => {
      image.src = event.target.result;
      image.style.pointerEvents = 'none'; // Helps to pick up both the image and the card
      card.appendChild(image);

// Save Data to Local Storage
const cardData = {
    imageSrc: image.src,
    row: card.parentNode.querySelector('.label')?.innerText, // Grab labels instead of rows. However will cause an error if we try to grab a div without a DOM element
}
window.localStorage.setItem(card.id, JSON.stringify(cardData)); // Takes cardData and stringifies it
  }
  reader.readAsDataURL(file); // Get parsed image data. Append image object to card
  }
  input.click();
}

const deleteCard = (event) => {  // When you click on the card, there is an alert to delete the card
  const willDeleteCard = window.confirm('Do you want to delete this card?'); // True or false
  if (willDeleteCard) { // If window.confirm = true, this will run
    event.target.remove(); // When it removes the card, delete from DOM
    window.localStorage.removeItem(event.target.id);
  }
}

const onDragStart = (event) => {
  console.log('dragging the element');
  event.dataTransfer.setData('id', event.target.id);
  setTimeout(() => {
    event.target.style.visibility = 'hidden';
  }, 50)
}

const onDragEnd = (event) => {
  event.target.style.visibility = 'visible';
  console.log('ended the drag');
}

cards.forEach((card, index) => {
  card.ondragstart = onDragStart;
  card.ondragend = onDragEnd;
})

// Logic upon first window load
window.onload = () => {
  const cardBank = document.querySelector('#bank')
  const keys = Object.keys(window.localStorage);
  keys.forEach((key) => {
    const cardData = JSON.parse(window.localStorage.getItem(key)); // Opposite of stringify
    const loadedCard = createCard(key, cardData); // Create card returns card we want to render
    const row = document.querySelectorAll('.row');
    const correctRow = Array.from(rows).find((row) => {
      return row.querySelector('.label').innerText === cardData.row;
    });
    if (correctRow) {
      correctRow.appendChild(loadedCard)
    } else
      cardBank.appendChild(loadedCard)
    });
  };
