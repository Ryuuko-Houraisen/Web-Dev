window.onload = () => {
  const keys = Object.keys(window.localStorage);
  keys.forEach((key) => {
    const cardData = JSON.parse(window.localStorage.getItem(key));
    console.log(key, cardData)
  });

}
